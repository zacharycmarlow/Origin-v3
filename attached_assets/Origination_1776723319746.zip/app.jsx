/* global React, ReactDOM, ORIGIN_CHAPTERS, Scene, load, save, loadProgress, saveProgress */

function hexToRgb(h) {
  const n = h.replace("#", "");
  return [0, 2, 4].map(i => parseInt(n.substr(i, 2), 16));
}

/* Chapter spine — vertical constellation */
function Spine({ chapters, current, onJump }) {
  return (
    <nav className="spine" aria-label="chapters">
      {chapters.map((c, i) => {
        const state = i === current ? "active" : i < current ? "past" : "future";
        return (
          <button
            key={i}
            className={"spine-node spine-" + state}
            onClick={() => onJump(i)}
            title={`${c.roman} · ${c.title}`}
          >
            <span className="spine-dot" />
            <span className="spine-roman">{c.roman}</span>
            <span className="spine-name">{c.title}</span>
          </button>
        );
      })}
    </nav>
  );
}

/* Backdrop with breathing veils */
function Backdrop({ territoryKey }) {
  return (
    <div className="backdrop" data-territory={territoryKey}>
      <div className="backdrop-base" />
      <div className="veil veil-1" />
      <div className="veil veil-2" />
      <div className="veil veil-3" />
      <div className="grain" />
      <svg width="0" height="0" style={{ position: 'absolute' }} aria-hidden="true">
        <defs>
          <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#f5e4a1" />
            <stop offset="18%" stopColor="#fff3c4" />
            <stop offset="40%" stopColor="#f2d27a" />
            <stop offset="55%" stopColor="#c89838" />
            <stop offset="72%" stopColor="#8b6218" />
            <stop offset="90%" stopColor="#f2d27a" />
            <stop offset="100%" stopColor="#f5e4a1" />
          </linearGradient>
          <radialGradient id="tealGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#4ff0d6" stopOpacity="0.9" />
            <stop offset="40%" stopColor="#2dd4c2" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#2dd4c2" stopOpacity="0" />
          </radialGradient>
          <filter id="paperFiber" x="-10%" y="-10%" width="120%" height="120%">
            <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="4" />
            <feColorMatrix values="0 0 0 0 0.3  0 0 0 0 0.22  0 0 0 0 0.12  0 0 0 0.4 0" />
            <feComposite in2="SourceGraphic" operator="in" />
          </filter>
        </defs>
      </svg>
    </div>
  );
}

/* ─── Tiles ─────────────────────────────── */
function PreludeTile({ onEnter }) {
  return (
    <div className="tile tile-prelude">
      <div className="tile-inner">
        <div className="prelude-glyph">
          <svg viewBox="0 0 120 120" width="120" height="120">
            <circle cx="60" cy="60" r="54" fill="none" stroke="currentColor" strokeWidth=".4" />
            <circle cx="60" cy="60" r="40" fill="none" stroke="currentColor" strokeWidth=".4" />
            <circle cx="60" cy="60" r="26" fill="none" stroke="currentColor" strokeWidth=".4" />
            <circle cx="60" cy="60" r="3" fill="currentColor" />
            {[0, 60, 120, 180, 240, 300].map(a => {
              const r1 = 26, r2 = 54;
              const rad = (a * Math.PI) / 180;
              return <line key={a}
                x1={60 + Math.cos(rad) * r1} y1={60 + Math.sin(rad) * r1}
                x2={60 + Math.cos(rad) * r2} y2={60 + Math.sin(rad) * r2}
                stroke="currentColor" strokeWidth=".4" />;
            })}
          </svg>
        </div>
        <div className="prelude-eyebrow">a guided excavation for the metamyth journey</div>
        <h1 className="prelude-title">THE ORIGIN</h1>
        <div className="prelude-sub">seven chapters · seven codes · seven thresholds</div>
        <div className="prelude-body">
          The world is made of stories. Your mind is creating one right now, so seamlessly you mistake the story for the world itself.
          The story running in your head is generating your reality. If you can reach the story, you can change what is real.
        </div>
        <div className="prelude-body dim">
          The north star: everything that happened to you happened for a reason — even if you are the one who makes that reason.
          The only adversary is shame. Each time it shows up, recognize it: the old story's immune system. Proof you are approaching something real.
        </div>
        <div className="prelude-before">
          <div className="before-head">before we begin</div>
          <div className="before-row"><div className="before-num">I</div><div className="before-text">stay with what surfaces — a raw emotion moves through the body in about ninety seconds.</div></div>
          <div className="before-row"><div className="before-num">II</div><div className="before-text">tell this in the past tense — shift from living it to narrating it.</div></div>
          <div className="before-row"><div className="before-num">III</div><div className="before-text">speak aloud if you can — the story lives in the voice and the breath.</div></div>
        </div>
        <button className="primary-btn" onClick={onEnter}>
          <span>begin</span><Arrow />
        </button>
      </div>
    </div>
  );
}

function EpilogueTile({ onRestart }) {
  return (
    <div className="tile tile-epilogue">
      <div className="tile-inner">
        <div className="prelude-glyph">
          <svg viewBox="0 0 120 120" width="120" height="120">
            <circle cx="60" cy="60" r="54" fill="none" stroke="currentColor" strokeWidth=".4" />
            <circle cx="60" cy="60" r="3" fill="currentColor" />
            <path d="M20 60 Q60 20 100 60 Q60 100 20 60" fill="none" stroke="currentColor" strokeWidth=".4" />
          </svg>
        </div>
        <div className="prelude-eyebrow">the beginning</div>
        <h1 className="prelude-title">CHAPTER ONE</h1>
        <div className="prelude-sub">everything you uncovered is chapter one</div>
        <p className="prelude-body">
          The power you just accessed is real. The Origin opened the door. The metamyth is the container — where your wounds reveal themselves as your qualification, where meaning sharpens into purpose, purpose rises into vision, and vision becomes a path you can walk.
        </p>
        <p className="prelude-body">
          Find one person and tell them your story. Then ask about theirs. That exchange is the oldest technology on earth.
        </p>
        <p className="prelude-body dim">The future we dream is one story away.</p>
        <button className="primary-btn" onClick={onRestart}><span>return to the origin</span></button>
      </div>
    </div>
  );
}

function Arrow() {
  return (
    <svg width="34" height="10" viewBox="0 0 34 10">
      <line x1="0" y1="5" x2="30" y2="5" stroke="currentColor" strokeWidth="1" />
      <polyline points="26,1 30,5 26,9" fill="none" stroke="currentColor" strokeWidth="1" />
    </svg>
  );
}

function OpenerTile({ chapter, idx, total }) {
  return (
    <div className="tile tile-opener">
      <div className="tile-inner">
        <div className="opener-meta">
          <span>chapter {String(idx + 1).padStart(2, "0")} of {String(total).padStart(2, "0")}</span>
          <span className="opener-rule" />
          <span>territory · {chapter.title.toLowerCase()}</span>
        </div>
        <div className="opener-roman">{chapter.roman}</div>
        <h1 className="opener-title">{chapter.title}</h1>
        <div className="opener-sub">{chapter.subtitle}</div>
        <div className="opener-invocation">{chapter.invocation}</div>
      </div>
    </div>
  );
}

function CodeTile({ chapter, idx, total }) {
  return (
    <div className="tile tile-code">
      <div className="tile-inner">
        <div className="code-card">
          <div className="code-head">
            <div className="code-mark">
              <svg viewBox="0 0 48 48" width="48" height="48">
                <circle cx="24" cy="24" r="22" fill="none" stroke="currentColor" strokeWidth=".5" />
                <circle cx="24" cy="24" r="14" fill="none" stroke="currentColor" strokeWidth=".5" />
                <circle cx="24" cy="24" r="5" fill="none" stroke="currentColor" strokeWidth=".8" />
                <line x1="24" y1="2" x2="24" y2="10" stroke="currentColor" strokeWidth=".5" />
                <line x1="24" y1="38" x2="24" y2="46" stroke="currentColor" strokeWidth=".5" />
                <line x1="2" y1="24" x2="10" y2="24" stroke="currentColor" strokeWidth=".5" />
                <line x1="38" y1="24" x2="46" y2="24" stroke="currentColor" strokeWidth=".5" />
              </svg>
            </div>
            <div className="code-label">{chapter.code.title}</div>
            <div className="code-num">ch · {chapter.roman}</div>
          </div>
          <div className="code-body">{chapter.code.body}</div>
        </div>
      </div>
    </div>
  );
}

function SceneTile({ scene, sceneIdx, totalScenes, chapterRoman, chapterTitle }) {
  return (
    <div className={"tile tile-scene tile-kind-" + scene.kind}>
      <div className="tile-inner">
        <div className="tile-header">
          <span className="tile-chapter">{chapterRoman} · {chapterTitle.toLowerCase()}</span>
          <span className="tile-progress">
            <span>{String(sceneIdx + 1).padStart(2, "0")}</span>
            <span className="sep">/</span>
            <span>{String(totalScenes).padStart(2, "0")}</span>
          </span>
        </div>
        <Scene scene={scene} idx={sceneIdx} total={totalScenes} />
      </div>
    </div>
  );
}

/* ─── Tile Navigator ─────────────────────── */
function Deck({ tiles, tileIdx, setTileIdx, chapters, tweaksOn }) {
  const [dir, setDir] = React.useState(1);
  const [animKey, setAnimKey] = React.useState(0);

  const go = React.useCallback((nextIdx) => {
    if (nextIdx < 0 || nextIdx >= tiles.length) return;
    setDir(nextIdx > tileIdx ? 1 : -1);
    setTileIdx(nextIdx);
    setAnimKey(k => k + 1);
  }, [tileIdx, tiles.length, setTileIdx]);

  React.useEffect(() => {
    const handler = (e) => {
      if (e.target.tagName === "TEXTAREA" || e.target.tagName === "INPUT") return;
      if (e.key === "ArrowRight" || e.key === "PageDown" || (e.key === " " && !e.shiftKey)) {
        e.preventDefault();
        go(tileIdx + 1);
      } else if (e.key === "ArrowLeft" || e.key === "PageUp") {
        e.preventDefault();
        go(tileIdx - 1);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [go, tileIdx]);

  const tile = tiles[tileIdx];
  const total = tiles.length;
  return (
    <div className="deck" data-kind={tile?.kind}>
      <div key={animKey} className={"tile-wrap dir-" + (dir > 0 ? "fwd" : "back")}>
        {tile && renderTile(tile, chapters)}
      </div>
      <DeckNav tileIdx={tileIdx} total={total} go={go} tiles={tiles} tile={tile} />
    </div>
  );
}

function renderTile(tile, chapters) {
  if (tile.kind === "prelude") return <PreludeTile onEnter={tile.onEnter} />;
  if (tile.kind === "epilogue") return <EpilogueTile onRestart={tile.onRestart} />;
  if (tile.kind === "opener") return <OpenerTile chapter={chapters[tile.ch]} idx={tile.ch} total={chapters.length} />;
  if (tile.kind === "code") return <CodeTile chapter={chapters[tile.ch]} idx={tile.ch} total={chapters.length} />;
  if (tile.kind === "scene") {
    const ch = chapters[tile.ch];
    return (
      <SceneTile
        scene={ch.scenes[tile.sc]}
        sceneIdx={tile.sc}
        totalScenes={ch.scenes.length}
        chapterRoman={ch.roman}
        chapterTitle={ch.title}
      />
    );
  }
  return null;
}

function DeckNav({ tileIdx, total, go, tiles, tile }) {
  // button label: if next tile is a new chapter, "cross the threshold"; if opener, "receive the code"; if code, "begin"; else "continue"
  const next = tiles[tileIdx + 1];
  let label = "continue";
  if (!next) label = "complete";
  else if (tile?.kind === "prelude") label = "enter chapter I";
  else if (tile?.kind === "opener") label = "receive the code";
  else if (tile?.kind === "code") label = "begin";
  else if (next.kind === "opener") label = "cross the threshold";
  else if (next.kind === "epilogue") label = "complete the origin";
  else if (tile?.scene?.kind === "threshold") label = "cross the threshold";

  return (
    <div className="deck-nav">
      <button className="nav-btn nav-back" onClick={() => go(tileIdx - 1)} disabled={tileIdx === 0}>
        <svg width="14" height="10" viewBox="0 0 14 10"><polyline points="5,1 1,5 5,9" fill="none" stroke="currentColor" strokeWidth="1" /><line x1="1" y1="5" x2="14" y2="5" stroke="currentColor" strokeWidth="1" /></svg>
        <span>back</span>
      </button>
      <div className="nav-progress">
        <span>{String(tileIdx + 1).padStart(2, "0")}</span>
        <div className="nav-track">
          <div className="nav-track-fill" style={{ width: ((tileIdx + 1) / total) * 100 + "%" }} />
        </div>
        <span>{String(total).padStart(2, "0")}</span>
      </div>
      <button className="nav-btn nav-fwd primary" onClick={() => go(tileIdx + 1)} disabled={tileIdx === total - 1}>
        <span>{label}</span>
        <svg width="14" height="10" viewBox="0 0 14 10"><line x1="0" y1="5" x2="13" y2="5" stroke="currentColor" strokeWidth="1" /><polyline points="9,1 13,5 9,9" fill="none" stroke="currentColor" strokeWidth="1" /></svg>
      </button>
    </div>
  );
}

/* ─── Tweaks ───────────────────────────────── */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "titleFont": "Pherome",
  "bodyFont": "Futura",
  "grainIntensity": 0.055
}/*EDITMODE-END*/;

function TweaksPanel({ visible, tweaks, setTweaks }) {
  if (!visible) return null;
  const update = (k, v) => {
    const n = { ...tweaks, [k]: v };
    setTweaks(n);
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [k]: v } }, "*");
  };
  return (
    <div className="tweaks">
      <div className="tweaks-title">Tweaks</div>
      <label>
        <span>title font</span>
        <select value={tweaks.titleFont} onChange={e => update("titleFont", e.target.value)}>
          <option>Pherome</option><option>Cormorant Garamond</option>
          <option>EB Garamond</option><option>Cinzel</option>
        </select>
      </label>
      <label>
        <span>body font</span>
        <select value={tweaks.bodyFont} onChange={e => update("bodyFont", e.target.value)}>
          <option>Futura</option><option>Jost</option>
          <option>Inter</option><option>EB Garamond</option>
        </select>
      </label>
      <label>
        <span>grain {Math.round(tweaks.grainIntensity * 100)}</span>
        <input type="range" min="0" max="0.2" step="0.01"
          value={tweaks.grainIntensity}
          onChange={e => update("grainIntensity", parseFloat(e.target.value))} />
      </label>
      <button className="btn-ghost small" onClick={() => {
        localStorage.removeItem("origin.v1");
        localStorage.removeItem("origin.progress");
        location.reload();
      }}>reset journey</button>
    </div>
  );
}

/* ─── Build tile list ──────────────────────── */
function buildTiles(chapters, onEnterBegin, onRestart) {
  const tiles = [];
  tiles.push({ kind: "prelude", onEnter: onEnterBegin });
  chapters.forEach((ch, ci) => {
    tiles.push({ kind: "opener", ch: ci });
    tiles.push({ kind: "code", ch: ci });
    ch.scenes.forEach((s, si) => {
      tiles.push({ kind: "scene", ch: ci, sc: si, scene: s });
    });
  });
  tiles.push({ kind: "epilogue", onRestart });
  return tiles;
}

/* ─── App ──────────────────────────────────── */
function App() {
  const chapters = window.ORIGIN_CHAPTERS;
  const [tileIdx, setTileIdx] = React.useState(() => {
    try { return parseInt(localStorage.getItem("origin.tile") || "0", 10) || 0; } catch { return 0; }
  });
  const [tweaks, setTweaks] = React.useState(TWEAK_DEFAULTS);
  const [tweaksOn, setTweaksOn] = React.useState(false);

  React.useEffect(() => { localStorage.setItem("origin.tile", String(tileIdx)); }, [tileIdx]);

  React.useEffect(() => {
    const handler = e => {
      if (e.data?.type === "__activate_edit_mode") setTweaksOn(true);
      if (e.data?.type === "__deactivate_edit_mode") setTweaksOn(false);
    };
    window.addEventListener("message", handler);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", handler);
  }, []);

  const restartToPrelude = () => setTileIdx(0);
  const enterBegin = () => setTileIdx(1);
  const tiles = React.useMemo(() => buildTiles(chapters, enterBegin, restartToPrelude), [chapters]);

  const currentTile = tiles[tileIdx];
  // Find current chapter for palette + spine
  let currentCh = 0;
  if (currentTile?.kind === "opener" || currentTile?.kind === "code" || currentTile?.kind === "scene") {
    currentCh = currentTile.ch;
  } else if (currentTile?.kind === "epilogue") {
    currentCh = chapters.length - 1;
  } else {
    currentCh = 0;
  }
  const isOutside = currentTile?.kind === "prelude" || currentTile?.kind === "epilogue";
  const palette = chapters[currentCh].palette;

  const rootStyle = {
    "--font-title": `"${tweaks.titleFont}", "Cormorant Garamond", serif`,
    "--font-body": `"${tweaks.bodyFont}", "Jost", "Helvetica Neue", sans-serif`,
    "--grain-op": tweaks.grainIntensity,
    "--density": "1",
    "--bg": palette.bg,
    "--ink": palette.ink,
    "--accent": palette.accent,
    "--veil": palette.veil,
    "--glow": palette.glow,
    "--shadow": palette.shadow || "#6b1e28"
  };

  const jumpToChapter = (ci) => {
    // find first opener for that chapter
    const i = tiles.findIndex(t => t.kind === "opener" && t.ch === ci);
    if (i >= 0) setTileIdx(i);
  };

  const territory = currentTile?.kind === "scene" ? currentTile.scene.kind : currentTile?.kind;

  return (
    <div className="app" style={rootStyle} data-stage={currentTile?.kind} data-chapter={currentCh}>
      <Backdrop territoryKey={territory} />

      {!isOutside && <Spine chapters={chapters} current={currentCh} onJump={jumpToChapter} />}

      <header className="topbar">
        <button className="mark" onClick={restartToPrelude}>
          <svg viewBox="0 0 24 24" width="14" height="14">
            <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth=".8" />
            <circle cx="12" cy="12" r="2" fill="currentColor" />
          </svg>
          <span>THE · ORIGIN</span>
        </button>
        <div className="topbar-right">
          {!isOutside && (
            <div className="chapter-count">{chapters[currentCh].roman} · {chapters[currentCh].title}</div>
          )}
        </div>
      </header>

      <main className="stage">
        <Deck tiles={tiles} tileIdx={tileIdx} setTileIdx={setTileIdx} chapters={chapters} tweaksOn={tweaksOn} />
      </main>

      <TweaksPanel visible={tweaksOn} tweaks={tweaks} setTweaks={setTweaks} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
