/* global React, ReactDOM */
const { useState, useEffect, useRef, useMemo, useCallback } = React;

/* ─── Storage ──────────────────────────────────────── */
const STORAGE = "origin.v1";
const load = () => { try { return JSON.parse(localStorage.getItem(STORAGE) || "{}"); } catch { return {}; } };
const save = (k, v) => {
  const d = load(); d[k] = v; localStorage.setItem(STORAGE, JSON.stringify(d));
};
const loadProgress = () => {
  try { return JSON.parse(localStorage.getItem("origin.progress") || '{"ch":0,"sc":0}'); }
  catch { return { ch: 0, sc: 0 }; }
};
const saveProgress = (p) => localStorage.setItem("origin.progress", JSON.stringify(p));

/* ─── Breath Pacer ─────────────────────────────────── */
function BreathPacer({ label, cycles = 3, onDone }) {
  const [phase, setPhase] = useState("idle"); // idle | in | hold | out | done
  const [cycle, setCycle] = useState(0);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    if (!running) return;
    if (phase === "idle") { setPhase("in"); return; }
    const dur = phase === "in" ? 4000 : phase === "out" ? 7000 : 700;
    const t = setTimeout(() => {
      if (phase === "in") setPhase("out");
      else if (phase === "out") {
        if (cycle + 1 >= cycles) { setPhase("done"); setRunning(false); onDone?.(); }
        else { setCycle(c => c + 1); setPhase("in"); }
      }
    }, dur);
    return () => clearTimeout(t);
  }, [phase, running, cycle, cycles, onDone]);

  const scale = phase === "in" ? 1 : phase === "out" ? 0.45 : phase === "done" ? 0.7 : 0.55;
  const dur = phase === "in" ? 4 : phase === "out" ? 7 : 0.7;

  return (
    <div className="breath">
      <div className="breath-orb-wrap">
        <div className="breath-orb" style={{ transform: `scale(${scale})`, transition: `transform ${dur}s cubic-bezier(.4,0,.4,1)` }} />
        <div className="breath-ring" />
        <div className="breath-phase">
          {phase === "idle" && "•"}
          {phase === "in" && "inhale"}
          {phase === "out" && "exhale"}
          {phase === "done" && "∎"}
        </div>
      </div>
      <div className="breath-label">{label}</div>
      <div className="breath-controls">
        {!running && phase !== "done" && (
          <button className="btn-ghost" onClick={() => { setCycle(0); setPhase("idle"); setRunning(true); }}>
            {phase === "idle" ? "begin" : "resume"}
          </button>
        )}
        {running && <div className="breath-cycle">{cycle + 1} / {cycles}</div>}
        {phase === "done" && <div className="breath-cycle">complete</div>}
      </div>
    </div>
  );
}

/* ─── 90-second stillness timer ─────────────────────── */
function StillTimer({ seconds = 90, label }) {
  const [remaining, setRemaining] = useState(seconds);
  const [running, setRunning] = useState(false);
  useEffect(() => {
    if (!running || remaining <= 0) return;
    const t = setTimeout(() => setRemaining(r => r - 1), 1000);
    return () => clearTimeout(t);
  }, [running, remaining]);
  const done = remaining === 0;
  const pct = ((seconds - remaining) / seconds) * 100;
  return (
    <div className="still">
      <svg className="still-ring" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="46" className="still-track" />
        <circle cx="50" cy="50" r="46" className="still-fill"
          style={{ strokeDasharray: 289, strokeDashoffset: 289 - (289 * pct / 100) }} />
      </svg>
      <div className="still-num">{done ? "∎" : `${remaining}`}</div>
      <div className="still-label">{label || `${seconds} seconds`}</div>
      {!running && !done && <button className="btn-ghost small" onClick={() => setRunning(true)}>begin</button>}
      {done && <div className="hint">let the silence finish the sentence</div>}
    </div>
  );
}

/* ─── Journal (persistent textarea) ──────────────────── */
function Journal({ sceneKey, placeholder, rows = 4, big }) {
  const [val, setVal] = useState(() => load()[sceneKey] || "");
  useEffect(() => { const t = setTimeout(() => save(sceneKey, val), 300); return () => clearTimeout(t); }, [val, sceneKey]);
  return (
    <div className={"journal" + (big ? " journal-big" : "")}>
      <textarea
        value={val}
        onChange={e => setVal(e.target.value)}
        placeholder={placeholder || "write here…"}
        rows={rows}
      />
      <div className="journal-meta">
        <span className="saved">{val ? `saved · ${val.trim().split(/\s+/).filter(Boolean).length} words` : "private to you"}</span>
      </div>
    </div>
  );
}

/* ─── Shame banner (recurring motif) ────────────────── */
function ShameMask({ body }) {
  const [seen, setSeen] = useState(() => !!load().shameSeen);
  return (
    <div className={"shame " + (seen ? "shame-seen" : "")}>
      <div className="shame-sigil">◈</div>
      <div className="shame-copy">
        <div className="shame-label">shame · the adversary</div>
        <div className="shame-body">{body}</div>
      </div>
      <button className="shame-btn" onClick={() => { save("shameSeen", true); setSeen(true); }}>
        {seen ? "recognized" : "I see the mask"}
      </button>
    </div>
  );
}

/* ─── Voices list (chapter II) ──────────────────────── */
function VoicesList({ sceneKey, title, body }) {
  const [items, setItems] = useState(() => load()[sceneKey] || []);
  const [text, setText] = useState("");
  const add = () => {
    if (!text.trim()) return;
    const next = [...items, text.trim()];
    setItems(next); save(sceneKey, next); setText("");
  };
  const remove = i => {
    const next = items.filter((_, j) => j !== i);
    setItems(next); save(sceneKey, next);
  };
  return (
    <div className="voices">
      <div className="voices-list">
        {items.map((v, i) => (
          <div key={i} className="voice-chip">
            <span className="voice-quote">“{v}”</span>
            <button className="voice-x" onClick={() => remove(i)} aria-label="remove">×</button>
          </div>
        ))}
      </div>
      <div className="voices-input">
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => e.key === "Enter" && add()}
          placeholder='"you are not enough"'
        />
        <button className="btn-ghost small" onClick={add}>+ add voice</button>
      </div>
    </div>
  );
}

/* ─── "I am" Declarations ───────────────────────────── */
function Declarations({ keys }) {
  const initial = useMemo(() => keys.map(k => load()[k] || ""), [keys]);
  const [vals, setVals] = useState(initial);
  const setAt = (i, v) => {
    const n = [...vals]; n[i] = v; setVals(n); save(keys[i], v);
  };
  return (
    <div className="decl">
      {keys.map((k, i) => (
        <div key={k} className="decl-row">
          <span className="decl-prefix">I am</span>
          <input value={vals[i]} onChange={e => setAt(i, e.target.value)} placeholder="…" />
        </div>
      ))}
    </div>
  );
}

/* ─── Gratitude ─────────────────────────────────────── */
function Gratitude({ items, keys }) {
  return (
    <div className="gratitude">
      {items.map((q, i) => (
        <div key={i} className="grat-row">
          <div className="grat-q">{q}</div>
          <Journal sceneKey={keys[i]} placeholder="" rows={2} />
        </div>
      ))}
    </div>
  );
}

/* ─── Gathering (Chapter VII) ───────────────────────── */
function Gathering({ lines }) {
  return (
    <div className="gather">
      {lines.map((l, i) => (
        <div key={i} className={"gather-line" + (l.fixed ? " fixed" : "")}>
          <div className="gather-label">{l.label}</div>
          {!l.fixed && <Journal sceneKey={l.key} placeholder="" rows={2} />}
        </div>
      ))}
    </div>
  );
}

/* ─── Movement / Embodiment timer ───────────────────── */
function MoveTimer({ seconds = 30, title, body }) {
  const [r, setR] = useState(seconds);
  const [run, setRun] = useState(false);
  useEffect(() => {
    if (!run || r <= 0) return;
    const t = setTimeout(() => setR(x => x - 1), 1000);
    return () => clearTimeout(t);
  }, [run, r]);
  return (
    <div className="move">
      <div className="move-dial">
        <div className="move-num">{r === 0 ? "∎" : r}</div>
        <div className="move-sub">{r === 0 ? "feel what stayed" : "seconds"}</div>
      </div>
      {!run && r > 0 && <button className="btn-ghost" onClick={() => setRun(true)}>begin</button>}
    </div>
  );
}

/* ─── Broadcast (long-form with word count) ─────────── */
function Broadcast({ sceneKey, minutes = 4 }) {
  const [val, setVal] = useState(() => load()[sceneKey] || "");
  const [elapsed, setElapsed] = useState(0);
  const [running, setRunning] = useState(false);
  useEffect(() => { const t = setTimeout(() => save(sceneKey, val), 300); return () => clearTimeout(t); }, [val, sceneKey]);
  useEffect(() => {
    if (!running) return;
    const t = setTimeout(() => setElapsed(e => e + 1), 1000);
    return () => clearTimeout(t);
  }, [running, elapsed]);
  const total = minutes * 60;
  const mm = String(Math.floor(elapsed / 60)).padStart(2, "0");
  const ss = String(elapsed % 60).padStart(2, "0");
  const pct = Math.min(100, (elapsed / total) * 100);
  return (
    <div className="broadcast">
      <div className="broadcast-bar">
        <div className="broadcast-time">{mm}:{ss}</div>
        <div className="broadcast-track"><div className="broadcast-fill" style={{ width: pct + "%" }} /></div>
        <button className="btn-ghost small" onClick={() => { setRunning(r => !r); }}>
          {running ? "pause" : elapsed === 0 ? "begin" : "resume"}
        </button>
      </div>
      <textarea
        value={val}
        onChange={e => setVal(e.target.value)}
        rows={14}
        placeholder="let it pour…"
        className="broadcast-ta"
      />
    </div>
  );
}

/* ─── Scene renderer ────────────────────────────────── */
function Scene({ scene, idx, total }) {
  return (
    <div className="scene">
      <div className="scene-index">
        <span>{String(idx + 1).padStart(2, "0")}</span>
        <span className="scene-sep">/</span>
        <span>{String(total).padStart(2, "0")}</span>
      </div>
      {scene.title && <h3 className="scene-title">{scene.title}</h3>}
      {scene.label && <div className="scene-label">{scene.label}</div>}
      {scene.body && <p className="scene-body">{scene.body}</p>}      {scene.kind === "arrive" && scene.breath && (
        <BreathPacer label={scene.breath.label} cycles={scene.breath.cycles} />
      )}
      {scene.kind === "breath" && (
        <BreathPacer label={scene.breath.label} cycles={scene.breath.cycles} />
      )}
      {scene.kind === "prompt" && (
        <Journal sceneKey={scene.key} placeholder="" rows={scene.rows || 4} />
      )}
      {scene.kind === "reflection" && <div className="reflection-mark">◦</div>}
      {scene.kind === "shame" && <ShameMask body={scene.body} />}
      {scene.kind === "threshold" && (
        <div className="threshold">
          <div className="threshold-rule" />
          {scene.prompt && (
            <Journal
              sceneKey={scene.prompt.key}
              placeholder={scene.prompt.placeholder}
              rows={scene.prompt.rows}
              big={scene.prompt.big}
            />
          )}
        </div>
      )}
      {scene.kind === "voices" && <VoicesList sceneKey={scene.key} />}
      {scene.kind === "gratitude" && <Gratitude items={scene.items} keys={scene.keys} />}
      {scene.kind === "declaration" && <Declarations keys={scene.keys} />}
      {scene.kind === "gathering" && <Gathering lines={scene.lines} />}
      {scene.kind === "outside" && (
        <div className="outside-card">
          <div className="outside-glyph">
            <svg viewBox="0 0 60 60" width="60" height="60">
              <circle cx="30" cy="30" r="10" fill="none" stroke="currentColor" strokeWidth=".8" />
              <circle cx="30" cy="30" r="20" fill="none" stroke="currentColor" strokeWidth=".4" opacity=".5" />
              <line x1="30" y1="4" x2="30" y2="14" stroke="currentColor" strokeWidth=".6" />
              <line x1="30" y1="46" x2="30" y2="56" stroke="currentColor" strokeWidth=".6" />
              <line x1="4" y1="30" x2="14" y2="30" stroke="currentColor" strokeWidth=".6" />
              <line x1="46" y1="30" x2="56" y2="30" stroke="currentColor" strokeWidth=".6" />
            </svg>
          </div>
          <div className="outside-note">put the screen down · return when the sky has answered</div>
        </div>
      )}
      {scene.kind === "movement" && <MoveTimer seconds={scene.seconds} />}
      {scene.kind === "embody" && <MoveTimer seconds={scene.seconds} />}
      {scene.kind === "broadcast" && <Broadcast sceneKey={scene.key} minutes={scene.minutes} />}
      {scene.kind === "finale" && (
        <div className="finale">
          <div className="finale-mark">∎</div>
          <div className="finale-words">the end.</div>
          <div className="finale-sub">the beginning of chapter one.</div>
        </div>
      )}

      {scene.after && (
        <div className="scene-after">
          {scene.after.map((line, i) => (
            <p key={i} className={"after-line after-" + (line.kind || "note")}>{line.text || line}</p>
          ))}
        </div>
      )}
      {scene.breathAfter && (
        <div className="scene-breath-after">
          <BreathPacer label={scene.breathAfter.label} cycles={scene.breathAfter.cycles} />
        </div>
      )}
    </div>
  );
}

Object.assign(window, {
  BreathPacer, StillTimer, Journal, ShameMask, VoicesList, Declarations,
  Gratitude, Gathering, MoveTimer, Broadcast, Scene,
  load, save, loadProgress, saveProgress
});
